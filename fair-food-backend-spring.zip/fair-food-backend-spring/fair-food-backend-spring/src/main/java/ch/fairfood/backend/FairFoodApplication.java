package ch.fairfood.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FairFoodApplication {

    public static void main(String[] args) {
        SpringApplication.run(FairFoodApplication.class, args);
    }
}
