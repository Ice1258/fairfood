INSERT INTO PRODUCT (name, brand, price, distance, origin, bio, expiry_days, discount) VALUES
 ('Bio Apfel','FairFood',1.49,2,'regional',TRUE,12,0.5),
 ('Heidelbeeren','BerryBest',2.99,8,'regional',FALSE,4,0.35),
 ('Banane','Tropica',0.79,15,'import',FALSE,7,0.7),
 ('Kiwi','Tropica',0.99,10,'import',TRUE,9,0.7),
 ('Karotte','FairFood',0.59,3,'regional',TRUE,14,0.15),
 ('Joghurt Natur','DairyDelight',0.69,5,'regional',FALSE,6,0.25),
 ('Bio Brot','Bäckerei Grün',2.49,1,'regional',TRUE,3,0.2),
 ('Hafermilch','Oatly',1.89,12,'import',TRUE,20,0.1);